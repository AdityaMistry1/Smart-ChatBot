from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB

# Training data
training_sentences = [
    "what time do you open", "when are you available", "working hours",
    "how do i return a product", "can i give something back",
    "what is the refund policy", "how long for refund",
    "how can i pay", "payment options",
    "i want to cancel my order", "how to cancel",
    "hello", "hi",
    "thanks", "thank you", "thank",
    "how do i check my balance", "check account balance",
    "what items are in my cart", "item list", "show my cart",
    "how do i contact support", "email for help",
    "any discounts available", "do you have offers"
]

training_labels = [
    "working_hours", "working_hours", "working_hours",
    "return_policy", "return_policy",
    "refund_policy", "refund_policy",
    "payment_methods", "payment_methods",
    "order_cancellation", "order_cancellation",
    "greeting", "greeting",
    "gratitude", "gratitude", "gratitude",
    "balance_check", "balance_check",
    "cart_info", "cart_info", "cart_info",
    "contact_support", "contact_support",
    "offers", "offers"
]

# Train model
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(training_sentences)
model = MultinomialNB()
model.fit(X, training_labels)

# Intent detection
def get_intent(user_input):
    user_vec = vectorizer.transform([user_input])
    return model.predict(user_vec)[0]

# Chatbot loop
def chatbot():
    print("Welcome to Customer Service! How can I assist you?")
    while True:
        user_input = input("You: ").lower()
        if user_input in ["bye", "exit"]:
            print("bot: bye! have a great day.")
            break

        intent = get_intent(user_input)

        if intent == "working_hours":
            print("bot: we're open from 9 AM to 5 PM, Monday to Friday.")
        elif intent == "return_policy":
            print("bot: you can return products within 30 days of purchase.")
        elif intent == "refund_policy":
            print("bot: the refund policy of every item is accepted 5 to 7 days of purchase.")
        elif intent == "payment_methods":
            print("bot: we accept online banking, credit cards, debit cards, google pay, phonepe, and paytm.")
        elif intent == "order_cancellation":
            print("bot: you can cancel your order from the MY ORDER section.")
        elif intent == "greeting":
            print("bot: hello! how can I help you?")
        elif intent == "gratitude":
            print("bot: you're welcome. can I help you with anything else?")
        elif intent == "balance_check":
            print("bot: you can check your balance from the account section of the user dashboard.")
        elif intent == "cart_info":
            print("bot: you can check your items from the CART section.")
        elif intent == "contact_support":
            print("bot: you can contact us through adt@gmail.com or our official email from the website.")
        elif intent == "offers":
            print("bot: you can find our limited time offers on the home page.")
        else:
            print("bot: sorry, I didn't understand that. can you try asking differently?")

# Start the chatbot
chatbot()