def chatbot():
    print("Welcome to Customer Service! How can i assist you you ?")
    while True:
        user_input = input("You:").lower()
        if "hours" in user_input or "time"in user_input or "open" in user_input:
            print("Bot: We're open from 9 AM to 5 PM, Monday to Friday.")
        elif "hello" in user_input or "hi" in user_input:
            print("Bot: hello how can i help you ?")
        elif "thanks" in user_input or "thank you" in user_input or "thank" in user_input :
            print("Bot: your welcome.Can i help you with anything else ?")    
        elif "refund" in user_input:
          print("bot:the refund policy of every item is accepted 5 to 7 days of purches.")
        elif "balance" in user_input:
          print("bot: you can check your balance from the account section of the user dashboard")
        elif "cancel" in user_input:
          print("bot: you can cancel your order from the MY OREDER section")
        elif "items" in user_input or "list" in user_input or "item" in user_input or "lists" in user_input:
          print("bot: you can check your items from CART section")
        elif "payment" in user_input or "pay" in user_input:
          print("bot:We accept online banking,Credit cards,Debit cards,Google Pay,Phonepay,Paytm.........your payment method is Google Pay")
        elif "return" in user_input:
            print("Bot: You can return products within 30 days of purchase.")
        elif "order" in user_input or "track" in user_input:
            print("Bot: You can track your order from your account dashboard.")
        elif "discount" in user_input or "offer" in user_input or "offers" in user_input or "discounts" in user_input:
            print("Bot: You can find the our limited time offers on the home page.")     
        elif "contact" in user_input or "support" in user_input or "email" in user_input:
          print("bot:you can contact us through adt@gmail.com or our official gmail from the website")
        elif "bye" in user_input or "exit" in user_input:
          print("Bye! Have a great day.")
          break
        else:
            print("Bot: Sorry, I didn't understand that. Can you try asking differently?")
chatbot()